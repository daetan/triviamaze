package mazeTest;

public class dataBaseTest {
	public static void main(String args[]) {

	}
}