package maze;

public class Main {
	public static void main(String[] args) {

		Player c = new Player();

		Maze m = new Maze(5, 5, c);
		m.playerMoveDirection("E");

		m.displayMaze();

	}

}
